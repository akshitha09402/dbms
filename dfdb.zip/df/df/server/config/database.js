const sqlite3 = require('sqlite3').verbose();
const path = require('path');
const bcrypt = require('bcrypt');

// Create database connection
const dbPath = path.resolve(__dirname, '../data/hydration.db');
console.log('Database path:', dbPath);

const db = new sqlite3.Database(dbPath, (err) => {
    if (err) {
        console.error('Error connecting to database:', err);
    } else {
        console.log('Connected to SQLite database');
        initializeDatabase();
    }
});

// Initialize database tables
function initializeDatabase() {
    db.serialize(() => {
        // Enable foreign keys
        db.run('PRAGMA foreign_keys = ON', (err) => {
            if (err) console.error('Error enabling foreign keys:', err);
        });

        // Users table
        db.run(`
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                fullName TEXT NOT NULL,
                email TEXT UNIQUE NOT NULL,
                password TEXT NOT NULL,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                last_login DATETIME
            )
        `, (err) => {
            if (err) console.error('Error creating users table:', err);
            else console.log('Users table created or already exists');
        });

        // Goals table
        db.run(`
            CREATE TABLE IF NOT EXISTS goals (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL,
                title TEXT NOT NULL,
                description TEXT,
                target_value INTEGER NOT NULL,
                unit TEXT NOT NULL,
                deadline DATE,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (user_id) REFERENCES users (id)
            )
        `, (err) => {
            if (err) console.error('Error creating goals table:', err);
        });

        // Hydration goals table
        db.run(`
            CREATE TABLE IF NOT EXISTS hydration_goals (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL,
                type TEXT NOT NULL,
                target_value INTEGER NOT NULL,
                unit TEXT DEFAULT 'ml',
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (user_id) REFERENCES users (id)
            )
        `, (err) => {
            if (err) console.error('Error creating hydration_goals table:', err);
        });

        // Hydration entries table
        db.run(`
            CREATE TABLE IF NOT EXISTS hydration_entries (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL,
                amount INTEGER NOT NULL,
                timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (user_id) REFERENCES users (id)
            )
        `, (err) => {
            if (err) console.error('Error creating hydration_entries table:', err);
        });

        // Weekly goals table
        db.run(`
            CREATE TABLE IF NOT EXISTS weekly_goals (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL,
                title TEXT NOT NULL,
                description TEXT,
                target_value INTEGER NOT NULL,
                unit TEXT DEFAULT 'ml',
                week_start DATE NOT NULL,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (user_id) REFERENCES users (id)
            )
        `, (err) => {
            if (err) console.error('Error creating weekly_goals table:', err);
        });

        // Create achievements table
        db.run(`
            CREATE TABLE IF NOT EXISTS achievements (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                description TEXT NOT NULL,
                icon TEXT NOT NULL,
                requirement INTEGER NOT NULL,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )
        `, (err) => {
            if (err) console.error('Error creating achievements table:', err);
            else {
                // Insert default achievements
                const defaultAchievements = [
                    ['First Sip', 'Track your first water intake', 'fa-tint', 1],
                    ['Daily Goal Achiever', 'Reach your daily goal', 'fa-trophy', 1],
                    ['Weekly Warrior', 'Meet your daily goal 7 days in a row', 'fa-fire', 7],
                    ['Hydration Master', 'Track water intake for 30 days', 'fa-crown', 30]
                ];

                const insertAchievement = db.prepare(`
                    INSERT OR IGNORE INTO achievements (name, description, icon, requirement)
                    VALUES (?, ?, ?, ?)
                `);

                defaultAchievements.forEach(achievement => {
                    insertAchievement.run(achievement, (err) => {
                        if (err) console.error('Error inserting achievement:', err);
                    });
                });

                insertAchievement.finalize();
            }
        });

        // Create user_achievements table
        db.run(`
            CREATE TABLE IF NOT EXISTS user_achievements (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL,
                achievement_id INTEGER NOT NULL,
                progress INTEGER DEFAULT 0,
                unlocked_at DATETIME,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (user_id) REFERENCES users (id),
                FOREIGN KEY (achievement_id) REFERENCES achievements (id),
                UNIQUE(user_id, achievement_id)
            )
        `, (err) => {
            if (err) console.error('Error creating user_achievements table:', err);
        });
    });
}

module.exports = db; 