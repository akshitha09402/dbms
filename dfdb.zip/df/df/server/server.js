const express = require('express');
const path = require('path');
const cors = require('cors');
const session = require('express-session');
const apiRoutes = require('./routes/api');

const app = express();
const port = process.env.PORT || 3000;

// Middleware
app.use(cors({
    origin: 'http://localhost:3000',
    credentials: true
}));
app.use(express.json());
app.use(session({
    secret: 'your-secret-key',
    resave: false,
    saveUninitialized: false,
    cookie: {
        secure: process.env.NODE_ENV === 'production',
        httpOnly: true,
        maxAge: 24 * 60 * 60 * 1000 // 24 hours
    }
}));

// Serve static files
app.use(express.static(path.join(__dirname, '../client')));

// API Routes
app.use('/api', apiRoutes);

// Serve HTML pages
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, '../client/pages/login.html'));
});

app.get('/signup', (req, res) => {
    res.sendFile(path.join(__dirname, '../client/pages/signup.html'));
});

app.get('/dashboard', (req, res) => {
    res.sendFile(path.join(__dirname, '../client/pages/dashboard.html'));
});

app.get('/track', (req, res) => {
    res.sendFile(path.join(__dirname, '../client/pages/track.html'));
});

app.get('/insights', (req, res) => {
    res.sendFile(path.join(__dirname, '../client/pages/insights.html'));
});

app.get('/goals', (req, res) => {
    res.sendFile(path.join(__dirname, '../client/pages/goals.html'));
});

app.get('/settings', (req, res) => {
    res.sendFile(path.join(__dirname, '../client/pages/settings.html'));
});

app.get('/analytics', (req, res) => {
    res.sendFile(path.join(__dirname, '../client/pages/analytics.html'));
});

app.get('/forgot-password', (req, res) => {
    res.sendFile(path.join(__dirname, '../client/pages/forgot-password.html'));
});

// Error handling middleware
app.use((err, req, res, next) => {
    console.error(err.stack);
    res.status(500).json({
        success: false,
        error: 'Something went wrong!'
    });
});

// Handle 404
app.use((req, res) => {
    if (req.path.startsWith('/api/')) {
        res.status(404).json({
            success: false,
            error: 'API route not found'
        });
    } else {
        res.sendFile(path.join(__dirname, '../client/pages/404.html'));
    }
});

// Start the server
app.listen(port, () => {
    console.log(`Server running at http://localhost:${port}`);
}); 