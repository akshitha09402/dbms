const db = require('../config/database');
const bcrypt = require('bcrypt');

// Database operations
const dbOperations = {
    // User operations
    createUser: (fullName, email, password) => {
        return new Promise((resolve, reject) => {
            console.log('Creating user:', { fullName, email });
            const query = 'INSERT INTO users (fullName, email, password) VALUES (?, ?, ?)';
            db.run(query, [fullName, email, password], function(err) {
                if (err) {
                    console.error('Database error creating user:', err);
                    reject(err);
                } else {
                    console.log('User created successfully:', { userId: this.lastID });
                    resolve(this.lastID);
                }
            });
        });
    },

    getUser: (userId) => {
        return new Promise((resolve, reject) => {
            console.log('Getting user by ID:', userId);
            const query = 'SELECT id, fullName, email, created_at, last_login FROM users WHERE id = ?';
            db.get(query, [userId], (err, user) => {
                if (err) {
                    console.error('Error getting user by ID:', err);
                    reject(err);
                } else {
                    console.log('User found:', user);
                    resolve(user);
                }
            });
        });
    },

    getUserByEmail: (email) => {
        return new Promise((resolve, reject) => {
            db.get('SELECT * FROM users WHERE email = ?', [email], (err, row) => {
                if (err) reject(err);
                else resolve(row);
            });
        });
    },

    updateLastLogin: (userId) => {
        return new Promise((resolve, reject) => {
            console.log('Updating last login for user:', userId);
            const query = 'UPDATE users SET last_login = CURRENT_TIMESTAMP WHERE id = ?';
            db.run(query, [userId], function(err) {
                if (err) {
                    console.error('Error updating last login:', err);
                    reject(err);
                } else {
                    console.log('Last login updated successfully');
                    resolve(this.changes > 0);
                }
            });
        });
    },

    loginUser: (email, password) => {
        return new Promise((resolve, reject) => {
            console.log('Attempting to find user:', { email });
            const query = 'SELECT * FROM users WHERE email = ?';
            db.get(query, [email], async (err, user) => {
                if (err) {
                    console.error('Database error during login:', err);
                    reject(err);
                } else if (!user) {
                    console.log('No user found with email:', email);
                    reject(new Error('User not found'));
                } else {
                    try {
                        const match = await bcrypt.compare(password, user.password);
                        if (match) {
                            console.log('Password match successful for user:', user.id);
                            resolve(user);
                        } else {
                            console.log('Invalid password for user:', user.id);
                            reject(new Error('Invalid password'));
                        }
                    } catch (error) {
                        console.error('Password comparison error:', error);
                        reject(error);
                    }
                }
            });
        });
    },

    // Hydration goals operations
    getDailyGoal: (userId) => {
        return new Promise((resolve, reject) => {
            const query = `
                SELECT target_value, unit
                FROM hydration_goals
                WHERE user_id = ? AND type = 'daily'
                ORDER BY created_at DESC
                LIMIT 1
            `;
            db.get(query, [userId], (err, goal) => {
                if (err) reject(err);
                else resolve(goal);
            });
        });
    },

    updateDailyGoal: (userId, targetValue) => {
        return new Promise((resolve, reject) => {
            const query = `
                INSERT INTO hydration_goals (user_id, type, target_value)
                VALUES (?, 'daily', ?)
            `;
            db.run(query, [userId, targetValue], function(err) {
                if (err) reject(err);
                else resolve(this.lastID);
            });
        });
    },

    getWeeklyGoals: (userId) => {
        return new Promise((resolve, reject) => {
            const query = `
                SELECT *
                FROM weekly_goals
                WHERE user_id = ?
                ORDER BY week_start DESC
            `;
            db.all(query, [userId], (err, goals) => {
                if (err) reject(err);
                else resolve(goals);
            });
        });
    },

    addWeeklyGoal: (userId, title, description, targetValue, unit) => {
        return new Promise((resolve, reject) => {
            const weekStart = new Date();
            weekStart.setHours(0, 0, 0, 0);
            weekStart.setDate(weekStart.getDate() - weekStart.getDay());

            const query = `
                INSERT INTO weekly_goals (user_id, title, description, target_value, unit, week_start)
                VALUES (?, ?, ?, ?, ?, ?)
            `;
            db.run(query, [userId, title, description, targetValue, unit, weekStart.toISOString()], function(err) {
                if (err) reject(err);
                else resolve(this.lastID);
            });
        });
    },

    // Hydration tracking operations
    addHydrationEntry: (userId, amount, timestamp = null) => {
        return new Promise((resolve, reject) => {
            const query = `
                INSERT INTO hydration_entries (user_id, amount, timestamp)
                VALUES (?, ?, COALESCE(?, CURRENT_TIMESTAMP))
            `;
            db.run(query, [userId, amount, timestamp], function(err) {
                if (err) {
                    console.error('Error adding hydration entry:', err);
                    reject(err);
                } else {
                    resolve(this.lastID);
                }
            });
        });
    },

    getDailyHydration: (userId, date) => {
        return new Promise((resolve, reject) => {
            const query = `
                SELECT SUM(amount) as total
                FROM hydration_entries
                WHERE user_id = ?
                AND date(timestamp) = date(?)
            `;
            db.get(query, [userId, date], (err, row) => {
                if (err) {
                    console.error('Error getting daily hydration:', err);
                    reject(err);
                } else {
                    resolve(row?.total || 0);
                }
            });
        });
    },

    getMonthlyHydration: (userId) => {
        return new Promise((resolve, reject) => {
            const query = `
                SELECT date(timestamp) as date, SUM(amount) as total
                FROM hydration_entries
                WHERE user_id = ?
                AND timestamp >= date('now', 'start of month')
                GROUP BY date(timestamp)
                ORDER BY date(timestamp)
            `;
            db.all(query, [userId], (err, rows) => {
                if (err) {
                    console.error('Error getting monthly hydration:', err);
                    reject(err);
                } else {
                    resolve(rows || []);
                }
            });
        });
    },

    getPeakHydrationTimes: (userId) => {
        return new Promise((resolve, reject) => {
            const query = `
                SELECT strftime('%H', timestamp) as hour,
                       COUNT(*) as frequency,
                       AVG(amount) as avg_amount
                FROM hydration_entries
                WHERE user_id = ?
                GROUP BY strftime('%H', timestamp)
                ORDER BY frequency DESC
            `;
            db.all(query, [userId], (err, rows) => {
                if (err) {
                    console.error('Error getting peak hydration times:', err);
                    reject(err);
                } else {
                    resolve(rows || []);
                }
            });
        });
    },

    getWeeklyPatterns: (userId) => {
        return new Promise((resolve, reject) => {
            const query = `
                SELECT strftime('%w', timestamp) as day_of_week,
                       AVG(amount) as avg_amount,
                       COUNT(*) as entry_count
                FROM hydration_entries
                WHERE user_id = ?
                GROUP BY strftime('%w', timestamp)
                ORDER BY day_of_week
            `;
            db.all(query, [userId], (err, rows) => {
                if (err) {
                    console.error('Error getting weekly patterns:', err);
                    reject(err);
                } else {
                    resolve(rows || []);
                }
            });
        });
    },

    getUserStreaks: (userId) => {
        return new Promise((resolve, reject) => {
            const query = `
                WITH daily_totals AS (
                    SELECT date(timestamp) as date,
                           SUM(amount) as total
                    FROM hydration_entries
                    WHERE user_id = ?
                    GROUP BY date(timestamp)
                )
                SELECT COUNT(*) as current_streak
                FROM (
                    SELECT date,
                           date(date, '-' || ROW_NUMBER() OVER (ORDER BY date) || ' days') as grp
                    FROM daily_totals
                    WHERE total >= (
                        SELECT target_value
                        FROM hydration_goals
                        WHERE user_id = ?
                        ORDER BY created_at DESC
                        LIMIT 1
                    )
                )
                GROUP BY grp
                ORDER BY MIN(date) DESC
                LIMIT 1
            `;
            db.get(query, [userId, userId], (err, row) => {
                if (err) {
                    console.error('Error getting user streaks:', err);
                    reject(err);
                } else {
                    resolve(row?.current_streak || 0);
                }
            });
        });
    },

    // Achievement operations
    getAchievements: (userId) => {
        return new Promise((resolve, reject) => {
            const query = `
                SELECT 
                    a.*,
                    CASE WHEN ua.unlocked_at IS NOT NULL THEN 1 ELSE 0 END as unlocked,
                    ua.progress
                FROM achievements a
                LEFT JOIN user_achievements ua ON a.id = ua.achievement_id AND ua.user_id = ?
                ORDER BY a.requirement ASC
            `;
            db.all(query, [userId], (err, achievements) => {
                if (err) reject(err);
                else resolve(achievements);
            });
        });
    },

    unlockAchievement: (userId, achievementId) => {
        return new Promise((resolve, reject) => {
            const query = `
                INSERT INTO user_achievements (user_id, achievement_id, unlocked_at)
                VALUES (?, ?, CURRENT_TIMESTAMP)
                ON CONFLICT (user_id, achievement_id)
                DO UPDATE SET unlocked_at = CURRENT_TIMESTAMP
                WHERE unlocked_at IS NULL
            `;
            db.run(query, [userId, achievementId], function(err) {
                if (err) reject(err);
                else resolve(this.changes > 0);
            });
        });
    },

    // Goal operations
    createGoal: (userId, title, description, targetValue, unit, deadline) => {
        return new Promise((resolve, reject) => {
            console.log('Creating goal:', { userId, title, targetValue, unit });
            const query = `
                INSERT INTO goals (user_id, title, description, target_value, unit, deadline)
                VALUES (?, ?, ?, ?, ?, ?)
            `;
            db.run(query, [userId, title, description, targetValue, unit, deadline], function(err) {
                if (err) {
                    console.error('Database error creating goal:', err);
                    reject(new Error('Failed to create goal'));
                } else {
                    console.log('Goal created successfully:', { goalId: this.lastID });
                    resolve(this.lastID);
                }
            });
        });
    },

    getGoals: (userId) => {
        return new Promise((resolve, reject) => {
            console.log('Fetching goals for user:', userId);
            const query = `
                SELECT 
                    id,
                    title,
                    description,
                    target_value,
                    current_value,
                    unit,
                    deadline,
                    status,
                    created_at
                FROM goals 
                WHERE user_id = ? 
                ORDER BY created_at DESC
            `;
            db.all(query, [userId], (err, goals) => {
                if (err) {
                    console.error('Database error fetching goals:', err);
                    reject(new Error('Failed to fetch goals'));
                } else {
                    console.log(`Found ${goals.length} goals for user:`, userId);
                    resolve(goals);
                }
            });
        });
    },

    // Tracking data operations
    addTrackingData: (userId, goalId, value, date, notes) => {
        return new Promise((resolve, reject) => {
            db.run(
                `INSERT INTO tracking_data (user_id, goal_id, value, date, notes)
                 VALUES (?, ?, ?, ?, ?)`,
                [userId, goalId, value, date, notes],
                function(err) {
                    if (err) reject(err);
                    else resolve(this.lastID);
                }
            );
        });
    },

    getTrackingData: (userId, goalId) => {
        return new Promise((resolve, reject) => {
            db.all(
                'SELECT * FROM tracking_data WHERE user_id = ? AND goal_id = ?',
                [userId, goalId],
                (err, rows) => {
                    if (err) reject(err);
                    else resolve(rows);
                }
            );
        });
    },

    // Analytics operations
    addAnalytics: (userId, goalId, metricName, metricValue, date) => {
        return new Promise((resolve, reject) => {
            db.run(
                `INSERT INTO analytics (user_id, goal_id, metric_name, metric_value, date)
                 VALUES (?, ?, ?, ?, ?)`,
                [userId, goalId, metricName, metricValue, date],
                function(err) {
                    if (err) reject(err);
                    else resolve(this.lastID);
                }
            );
        });
    },

    getAnalytics: (userId, goalId) => {
        return new Promise((resolve, reject) => {
            db.all(
                'SELECT * FROM analytics WHERE user_id = ? AND goal_id = ?',
                [userId, goalId],
                (err, rows) => {
                    if (err) reject(err);
                    else resolve(rows);
                }
            );
        });
    },

    // User settings operations
    updateUserSettings: (userId, theme, notificationsEnabled, measurementUnit) => {
        return new Promise((resolve, reject) => {
            db.run(
                `INSERT INTO user_settings (user_id, theme, notifications_enabled, measurement_unit)
                 VALUES (?, ?, ?, ?)
                 ON CONFLICT(user_id) DO UPDATE SET
                 theme = excluded.theme,
                 notifications_enabled = excluded.notifications_enabled,
                 measurement_unit = excluded.measurement_unit,
                 updated_at = CURRENT_TIMESTAMP`,
                [userId, theme, notificationsEnabled, measurementUnit],
                function(err) {
                    if (err) reject(err);
                    else resolve(this.lastID);
                }
            );
        });
    },

    getUserSettings: (userId) => {
        return new Promise((resolve, reject) => {
            db.get('SELECT * FROM user_settings WHERE user_id = ?', [userId], (err, row) => {
                if (err) reject(err);
                else resolve(row);
            });
        });
    },

    // Get achievement progress
    getAchievementProgress: (userId) => {
        return new Promise((resolve, reject) => {
            const query = `
                SELECT a.*, ua.progress, ua.unlocked_at
                FROM achievements a
                LEFT JOIN user_achievements ua ON a.id = ua.achievement_id AND ua.user_id = ?
                ORDER BY a.requirement
            `;
            db.all(query, [userId], (err, rows) => {
                if (err) {
                    console.error('Error getting achievement progress:', err);
                    reject(err);
                } else {
                    resolve(rows || []);
                }
            });
        });
    },

    // Update achievement progress
    updateAchievementProgress: (userId, achievementId, progress) => {
        return new Promise((resolve, reject) => {
            const query = `
                INSERT INTO user_achievements (user_id, achievement_id, progress)
                VALUES (?, ?, ?)
                ON CONFLICT(user_id, achievement_id)
                DO UPDATE SET progress = ?,
                             unlocked_at = CASE 
                                 WHEN ? >= (SELECT requirement FROM achievements WHERE id = ?)
                                 AND unlocked_at IS NULL
                                 THEN CURRENT_TIMESTAMP
                                 ELSE unlocked_at
                             END
            `;
            db.run(query, [userId, achievementId, progress, progress, progress, achievementId], (err) => {
                if (err) {
                    console.error('Error updating achievement progress:', err);
                    reject(err);
                } else {
                    resolve();
                }
            });
        });
    }
};

// Export all operations
module.exports = dbOperations; 