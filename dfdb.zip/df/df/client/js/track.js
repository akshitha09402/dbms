// Check if user is logged in
const userId = localStorage.getItem('userId');
if (!userId) {
    window.location.href = 'login.html';
}

// DOM Elements
const presetBtns = document.querySelectorAll('.preset-btn');
const customAmountInput = document.getElementById('customAmount');
const addCustomAmountBtn = document.getElementById('addCustomAmount');
const reminderToggle = document.getElementById('reminderToggle');
const reminderInterval = document.getElementById('reminderInterval');
const startTime = document.getElementById('startTime');
const endTime = document.getElementById('endTime');
const historyList = document.getElementById('historyList');
const logoutBtn = document.getElementById('logoutBtn');

// State
let state = {
    dailyGoal: 2000,
    currentAmount: 0,
    weeklyData: [],
    history: [],
    reminders: {
        enabled: true,
        interval: 60,
        startTime: '08:00',
        endTime: '22:00'
    }
};

// Initialize charts
let progressChart;
let weeklyChart;

// Initialize
document.addEventListener('DOMContentLoaded', async () => {
    await loadUserData();
    initializeCharts();
    setupEventListeners();
    if (state.reminders.enabled) {
        setupReminders();
    }
});

// Load user data
async function loadUserData() {
    try {
        // Load daily goal and progress
        const [dailyGoalResponse, dailyProgressResponse] = await Promise.all([
            fetch('/api/hydration/daily-goal', {
                credentials: 'include'
            }),
            fetch('/api/hydration/daily', {
                credentials: 'include'
            })
        ]);

        if (dailyGoalResponse.ok) {
            const { target_value } = await dailyGoalResponse.json();
            state.dailyGoal = target_value;
        }

        if (dailyProgressResponse.ok) {
            const { total } = await dailyProgressResponse.json();
            state.currentAmount = total || 0;
        }

        // Load weekly data
        const weeklyResponse = await fetch('/api/hydration/weekly-goals', {
            credentials: 'include'
        });

        if (weeklyResponse.ok) {
            state.weeklyData = await weeklyResponse.json();
        }

        // Load history
        const historyResponse = await fetch('/api/hydration/daily?days=7', {
            credentials: 'include'
        });

        if (historyResponse.ok) {
            state.history = await historyResponse.json();
        }

        updateUI();
    } catch (error) {
        console.error('Error loading user data:', error);
        showError('Failed to load user data');
    }
}

// Initialize charts
function initializeCharts() {
    // Progress chart
    const progressCtx = document.getElementById('progressChart').getContext('2d');
    progressChart = new Chart(progressCtx, {
        type: 'doughnut',
        data: {
            datasets: [{
                data: [state.currentAmount, state.dailyGoal - state.currentAmount],
                backgroundColor: ['#4CAF50', '#f0f0f0']
            }]
        },
        options: {
            cutout: '80%',
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    display: false
                }
            }
        }
    });

    // Weekly chart
    const weeklyCtx = document.getElementById('weeklyChart').getContext('2d');
    weeklyChart = new Chart(weeklyCtx, {
        type: 'bar',
        data: {
            labels: getLastSevenDays(),
            datasets: [{
                label: 'Daily Intake (ml)',
                data: state.weeklyData.map(day => day.amount),
                backgroundColor: '#4CAF50'
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                y: {
                    beginAtZero: true,
                    title: {
                        display: true,
                        text: 'Water Intake (ml)'
                    }
                }
            }
        }
    });
}

// Setup event listeners
function setupEventListeners() {
    // Preset buttons
    presetBtns.forEach(btn => {
        btn.addEventListener('click', () => {
            const amount = parseInt(btn.dataset.amount);
            addWaterIntake(amount);
        });
    });

    // Custom amount
    addCustomAmountBtn.addEventListener('click', () => {
        const amount = parseInt(customAmountInput.value);
        if (amount > 0) {
            addWaterIntake(amount);
            customAmountInput.value = '';
        } else {
            showError('Please enter a valid amount');
        }
    });

    // Reminder settings
    reminderToggle.addEventListener('change', () => {
        state.reminders.enabled = reminderToggle.checked;
        if (state.reminders.enabled) {
            setupReminders();
        } else {
            clearReminders();
        }
        saveReminderSettings();
    });

    reminderInterval.addEventListener('change', () => {
        state.reminders.interval = parseInt(reminderInterval.value);
        if (state.reminders.enabled) {
            setupReminders();
        }
        saveReminderSettings();
    });

    startTime.addEventListener('change', () => {
        state.reminders.startTime = startTime.value;
        if (state.reminders.enabled) {
            setupReminders();
        }
        saveReminderSettings();
    });

    endTime.addEventListener('change', () => {
        state.reminders.endTime = endTime.value;
        if (state.reminders.enabled) {
            setupReminders();
        }
        saveReminderSettings();
    });

    // Logout
    logoutBtn.addEventListener('click', () => {
        localStorage.removeItem('userId');
        window.location.href = 'login.html';
    });
}

// Add water intake
async function addWaterIntake(amount) {
    try {
        const response = await fetch('/api/hydration/track', {
            method: 'POST',
            credentials: 'include',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                amount,
                timestamp: new Date().toISOString()
            })
        });

        if (response.ok) {
            state.currentAmount += amount;
            updateUI();
            showSuccess(`Added ${amount}ml of water`);
            checkAchievements();
        } else {
            throw new Error('Failed to track water intake');
        }
    } catch (error) {
        console.error('Error tracking water intake:', error);
        showError('Failed to track water intake');
    }
}

// Update UI
function updateUI() {
    // Update progress chart
    progressChart.data.datasets[0].data = [
        state.currentAmount,
        Math.max(0, state.dailyGoal - state.currentAmount)
    ];
    progressChart.update();

    // Update progress text
    document.querySelector('.current').textContent = `${state.currentAmount}`;
    document.querySelector('.target').textContent = `/ ${state.dailyGoal}ml`;

    // Update weekly chart
    weeklyChart.data.datasets[0].data = state.weeklyData.map(day => day.amount);
    weeklyChart.update();

    // Update history
    updateHistory();
}

// Update history
function updateHistory() {
    if (!historyList) return;
    
    historyList.innerHTML = state.history
        .map(entry => `
            <div class="history-entry">
                <div class="history-time">${formatTime(entry.timestamp)}</div>
                <div class="history-amount">${entry.amount}ml</div>
            </div>
        `)
        .join('');
}

// Setup reminders
function setupReminders() {
    clearReminders();
    if (!state.reminders.enabled) return;

    const now = new Date();
    const start = new Date(now.toDateString() + ' ' + state.reminders.startTime);
    const end = new Date(now.toDateString() + ' ' + state.reminders.endTime);

    if (now >= start && now <= end) {
        scheduleReminder();
    }
}

// Schedule next reminder
function scheduleReminder() {
    const interval = state.reminders.interval * 60 * 1000; // Convert minutes to milliseconds
    setTimeout(() => {
        showReminder();
        scheduleReminder();
    }, interval);
}

// Show reminder notification
function showReminder() {
    if (!("Notification" in window)) return;

    if (Notification.permission === "granted") {
        new Notification("Hydration Reminder", {
            body: "Time to drink some water!",
            icon: "../assets/water-drop.png"
        });
    } else if (Notification.permission !== "denied") {
        Notification.requestPermission().then(permission => {
            if (permission === "granted") {
                showReminder();
            }
        });
    }
}

// Clear reminders
function clearReminders() {
    // Clear all scheduled reminders
}

// Save reminder settings
function saveReminderSettings() {
    localStorage.setItem('reminderSettings', JSON.stringify(state.reminders));
}

// Check achievements
function checkAchievements() {
    // Daily goal achievement
    if (state.currentAmount >= state.dailyGoal) {
        showSuccess('Achievement Unlocked: Daily Goal Reached! 🎉');
    }

    // First intake of the day
    if (state.currentAmount === state.dailyGoal) {
        showSuccess('Achievement Unlocked: Early Bird! 🌅');
    }
}

// Utility functions
function getLastSevenDays() {
    const days = [];
    for (let i = 6; i >= 0; i--) {
        const date = new Date();
        date.setDate(date.getDate() - i);
        days.push(date.toLocaleDateString('en-US', { weekday: 'short' }));
    }
    return days;
}

function formatTime(timestamp) {
    return new Date(timestamp).toLocaleTimeString('en-US', {
        hour: 'numeric',
        minute: '2-digit',
        hour12: true
    });
}

// Toast notifications
function showSuccess(message) {
    const toast = document.createElement('div');
    toast.className = 'toast success';
    toast.textContent = message;
    document.body.appendChild(toast);
    
    setTimeout(() => {
        toast.classList.add('show');
        setTimeout(() => {
            toast.classList.remove('show');
            setTimeout(() => toast.remove(), 300);
        }, 3000);
    }, 100);
}

function showError(message) {
    const toast = document.createElement('div');
    toast.className = 'toast error';
    toast.textContent = message;
    document.body.appendChild(toast);
    
    setTimeout(() => {
        toast.classList.add('show');
        setTimeout(() => {
            toast.classList.remove('show');
            setTimeout(() => toast.remove(), 300);
        }, 3000);
    }, 100);
} 