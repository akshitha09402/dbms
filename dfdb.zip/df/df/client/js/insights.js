// Check if user is logged in
const userId = localStorage.getItem('userId');
if (!userId) {
    window.location.href = 'login.html';
}

// DOM Elements
const monthlyChart = document.getElementById('monthlyChart');
const peakTimesChart = document.getElementById('peakTimesChart');
const patternsChart = document.getElementById('patternsChart');
const streakCalendar = document.getElementById('streakCalendar');
const achievementProgress = document.getElementById('achievementProgress');
const recommendations = document.getElementById('recommendations');
const currentStreakElement = document.querySelector('.current-streak .streak-number');
const bestStreakElement = document.querySelector('.best-streak .streak-number');
const logoutBtn = document.getElementById('logoutBtn');

// State
let state = {
    monthlyData: [],
    peakTimes: [],
    weeklyPatterns: [],
    streaks: {
        current: 0,
        best: 0,
        calendar: []
    },
    achievements: [],
    userStats: {}
};

// Initialize
document.addEventListener('DOMContentLoaded', async () => {
    await loadInsightsData();
    initializeCharts();
    updateStreakInfo();
    updateAchievements();
    generateRecommendations();
    setupEventListeners();
});

// Load insights data
async function loadInsightsData() {
    try {
        const [monthlyResponse, peakTimesResponse, streaksResponse, achievementsResponse] = await Promise.all([
            fetch('/api/hydration/monthly', {
                credentials: 'include'
            }),
            fetch('/api/hydration/peak-times', {
                credentials: 'include'
            }),
            fetch('/api/hydration/streaks', {
                credentials: 'include'
            }),
            fetch('/api/achievements', {
                credentials: 'include'
            })
        ]);

        if (monthlyResponse.ok) {
            state.monthlyData = await monthlyResponse.json();
        }

        if (peakTimesResponse.ok) {
            state.peakTimes = await peakTimesResponse.json();
        }

        if (streaksResponse.ok) {
            const streakData = await streaksResponse.json();
            state.streaks = {
                current: streakData.currentStreak,
                best: streakData.bestStreak,
                calendar: streakData.calendar
            };
        }

        if (achievementsResponse.ok) {
            state.achievements = await achievementsResponse.json();
        }

    } catch (error) {
        console.error('Error loading insights data:', error);
        showError('Failed to load insights data');
    }
}

// Initialize charts
function initializeCharts() {
    // Monthly Overview Chart
    new Chart(monthlyChart, {
        type: 'line',
        data: {
            labels: getLastThirtyDays(),
            datasets: [{
                label: 'Daily Water Intake (ml)',
                data: state.monthlyData.map(day => day.amount),
                borderColor: '#2196F3',
                backgroundColor: 'rgba(33, 150, 243, 0.1)',
                fill: true,
                tension: 0.4
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    display: false
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    title: {
                        display: true,
                        text: 'Water Intake (ml)'
                    }
                }
            }
        }
    });

    // Peak Times Chart
    new Chart(peakTimesChart, {
        type: 'bar',
        data: {
            labels: ['6AM', '9AM', '12PM', '3PM', '6PM', '9PM'],
            datasets: [{
                label: 'Average Intake (ml)',
                data: state.peakTimes.map(time => time.average),
                backgroundColor: '#4CAF50'
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    display: false
                }
            },
            scales: {
                y: {
                    beginAtZero: true
                }
            }
        }
    });

    // Weekly Patterns Chart
    new Chart(patternsChart, {
        type: 'radar',
        data: {
            labels: ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'],
            datasets: [{
                label: 'Average Daily Intake (ml)',
                data: state.weeklyPatterns,
                backgroundColor: 'rgba(33, 150, 243, 0.2)',
                borderColor: '#2196F3',
                pointBackgroundColor: '#2196F3'
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                r: {
                    beginAtZero: true
                }
            }
        }
    });
}

// Update streak information
function updateStreakInfo() {
    // Update streak numbers
    currentStreakElement.textContent = state.streaks.current;
    bestStreakElement.textContent = state.streaks.best;

    // Update calendar
    streakCalendar.innerHTML = '';
    state.streaks.calendar.forEach(day => {
        const dayElement = document.createElement('div');
        dayElement.className = `calendar-day${day.completed ? ' completed' : ''}`;
        dayElement.title = `${day.date}: ${day.completed ? 'Goal completed' : 'Goal not met'}`;
        streakCalendar.appendChild(dayElement);
    });
}

// Update achievements
function updateAchievements() {
    achievementProgress.innerHTML = state.achievements
        .map(achievement => `
            <div class="achievement-item">
                <div class="achievement-icon">
                    <i class="fas ${achievement.icon}"></i>
                </div>
                <div class="achievement-details">
                    <div class="achievement-name">${achievement.name}</div>
                    <div class="achievement-progress-bar">
                        <div class="achievement-progress-fill" style="width: ${achievement.progress}%"></div>
                    </div>
                </div>
            </div>
        `)
        .join('');
}

// Generate recommendations
function generateRecommendations() {
    const recommendationsList = [
        {
            icon: 'fa-clock',
            text: 'Your peak hydration time is around 3 PM. Try to maintain this pattern for optimal hydration.'
        },
        {
            icon: 'fa-calendar-check',
            text: 'You\'re most consistent with your water intake on Wednesdays. Apply this routine to other days!'
        },
        {
            icon: 'fa-chart-line',
            text: 'Your weekly average is improving! Keep up the good work to maintain this positive trend.'
        }
    ];

    recommendations.innerHTML = recommendationsList
        .map(rec => `
            <div class="recommendation-item">
                <i class="fas ${rec.icon} recommendation-icon"></i>
                <div class="recommendation-text">${rec.text}</div>
            </div>
        `)
        .join('');
}

// Setup event listeners
function setupEventListeners() {
    logoutBtn.addEventListener('click', () => {
        localStorage.removeItem('userId');
        window.location.href = 'login.html';
    });
}

// Utility functions
function getLastThirtyDays() {
    const days = [];
    for (let i = 29; i >= 0; i--) {
        const date = new Date();
        date.setDate(date.getDate() - i);
        days.push(date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' }));
    }
    return days;
}

// Toast notifications
function showError(message) {
    const toast = document.createElement('div');
    toast.className = 'toast error';
    toast.textContent = message;
    document.body.appendChild(toast);
    
    setTimeout(() => {
        toast.classList.add('show');
        setTimeout(() => {
            toast.classList.remove('show');
            setTimeout(() => toast.remove(), 300);
        }, 3000);
    }, 100);
} 