// DOM Elements
const editDailyGoalBtn = document.getElementById('editDailyGoalBtn');
const editDailyGoalModal = document.getElementById('editDailyGoalModal');
const dailyGoalInput = document.getElementById('dailyGoalInput');
const presetGoals = document.querySelectorAll('.preset-btn');
const saveDailyGoalBtn = document.getElementById('saveDailyGoal');
const cancelDailyGoalBtn = document.getElementById('cancelDailyGoal');
const addWeeklyGoalBtn = document.getElementById('addWeeklyGoalBtn');
const addWeeklyGoalModal = document.getElementById('addWeeklyGoalModal');
const saveWeeklyGoalBtn = document.getElementById('saveWeeklyGoal');
const cancelWeeklyGoalBtn = document.getElementById('cancelWeeklyGoal');
const achievementFilters = document.querySelectorAll('.achievement-filters .btn');

// Check if user is logged in
const userId = localStorage.getItem('userId');
if (!userId) {
    window.location.href = 'login.html';
}

// State
let state = {
    dailyGoal: {
        current: 0,
        target: 2000
    },
    weeklyGoals: []
};

let achievements = [
    {
        id: 1,
        title: 'First Steps',
        description: 'Log your first water intake',
        unlocked: true,
        date: '2024-03-10'
    },
    {
        id: 2,
        title: 'Week Warrior',
        description: 'Complete your daily goal for 7 days straight',
        unlocked: true,
        date: '2024-03-14'
    },
    {
        id: 3,
        title: 'Hydration Master',
        description: 'Maintain perfect hydration for 30 days',
        unlocked: false,
        progress: 15,
        target: 30
    }
];

// Initialize
document.addEventListener('DOMContentLoaded', async () => {
    try {
        // Load daily goal
        const dailyGoalResponse = await fetch('/api/hydration/daily-goal', {
            credentials: 'include',
            headers: { 'Authorization': `Bearer ${localStorage.getItem('token')}` }
        });
        if (dailyGoalResponse.ok) {
            const dailyGoal = await dailyGoalResponse.json();
            state.dailyGoal.target = dailyGoal.target_value;
        }

        // Load daily progress
        const dailyProgressResponse = await fetch('/api/hydration/daily', {
            credentials: 'include',
            headers: { 'Authorization': `Bearer ${localStorage.getItem('token')}` }
        });
        if (dailyProgressResponse.ok) {
            const { total } = await dailyProgressResponse.json();
            state.dailyGoal.current = total || 0;
        }

        // Load weekly goals
        const weeklyGoalsResponse = await fetch('/api/hydration/weekly-goals', {
            credentials: 'include',
            headers: { 'Authorization': `Bearer ${localStorage.getItem('token')}` }
        });
        if (weeklyGoalsResponse.ok) {
            state.weeklyGoals = await weeklyGoalsResponse.json() || [];
        }

        // Update UI
        updateUI();
        updateAchievements();
    } catch (error) {
        console.error('Error loading goals:', error);
        showError('Failed to load goals. Please try again.');
    }
});

// Event Listeners
if (editDailyGoalBtn) {
    editDailyGoalBtn.addEventListener('click', () => {
        if (editDailyGoalModal && dailyGoalInput) {
            dailyGoalInput.value = state.dailyGoal.target;
            editDailyGoalModal.classList.add('active');
        }
    });
}

if (addWeeklyGoalBtn) {
    addWeeklyGoalBtn.addEventListener('click', () => {
        if (addWeeklyGoalModal) {
            addWeeklyGoalModal.classList.add('active');
        }
    });
}

// Close modals when clicking outside
document.querySelectorAll('.modal').forEach(modal => {
    modal.addEventListener('click', (e) => {
        if (e.target === modal) {
            modal.classList.remove('active');
        }
    });
});

// Close buttons
document.querySelectorAll('.close-btn').forEach(btn => {
    btn.addEventListener('click', (e) => {
        const modal = e.target.closest('.modal');
        if (modal) {
            modal.classList.remove('active');
        }
    });
});

// Cancel buttons
if (cancelDailyGoalBtn) {
    cancelDailyGoalBtn.addEventListener('click', () => {
        if (editDailyGoalModal) {
            editDailyGoalModal.classList.remove('active');
        }
    });
}

if (cancelWeeklyGoalBtn) {
    cancelWeeklyGoalBtn.addEventListener('click', () => {
        if (addWeeklyGoalModal) {
            addWeeklyGoalModal.classList.remove('active');
        }
    });
}

// Preset goal buttons
presetGoals.forEach(btn => {
    btn.addEventListener('click', () => {
        if (dailyGoalInput) {
            dailyGoalInput.value = btn.dataset.amount;
        }
    });
});

// Save daily goal
if (saveDailyGoalBtn) {
    saveDailyGoalBtn.addEventListener('click', async () => {
        const newGoal = parseInt(dailyGoalInput.value);
        if (newGoal < 500) {
            showError('Daily goal must be at least 500ml');
            return;
        }

        try {
            const response = await fetch('/api/hydration/daily-goal', {
                method: 'POST',
                credentials: 'include',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ target: newGoal })
            });

            if (!response.ok) {
                const errorData = await response.json();
                throw new Error(errorData.error || 'Failed to update daily goal');
            }

            state.dailyGoal.target = newGoal;
            updateUI();
            if (editDailyGoalModal) {
                editDailyGoalModal.classList.remove('active');
            }
            showSuccess('Daily goal updated successfully');
        } catch (error) {
            console.error('Error updating daily goal:', error);
            showError(error.message);
        }
    });
}

// Save weekly goal
if (saveWeeklyGoalBtn) {
    saveWeeklyGoalBtn.addEventListener('click', async () => {
        const titleInput = document.getElementById('goalTitle');
        const descriptionInput = document.getElementById('goalDescription');
        const targetInput = document.getElementById('goalTarget');
        const unitInput = document.getElementById('goalUnit');

        if (!titleInput || !targetInput) {
            showError('Missing form elements');
            return;
        }

        const title = titleInput.value.trim();
        const description = descriptionInput ? descriptionInput.value.trim() : '';
        const target = parseInt(targetInput.value);
        const unit = unitInput ? unitInput.value : 'ml';

        if (!title || !target) {
            showError('Please fill in all required fields');
            return;
        }

        try {
            const response = await fetch('/api/hydration/weekly-goals', {
                method: 'POST',
                credentials: 'include',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${localStorage.getItem('token')}`
                },
                body: JSON.stringify({ title, description, target, unit })
            });

            if (response.ok) {
                const { goalId } = await response.json();
                state.weeklyGoals.push({
                    id: goalId,
                    title,
                    description,
                    target,
                    current: 0,
                    unit
                });
                updateUI();
                if (addWeeklyGoalModal) {
                    addWeeklyGoalModal.classList.remove('active');
                }
                const goalForm = document.getElementById('goalForm');
                if (goalForm) {
                    goalForm.reset();
                }
                showSuccess('Weekly goal added successfully');
            } else {
                throw new Error('Failed to add weekly goal');
            }
        } catch (error) {
            showError(error.message);
        }
    });
}

// Update UI
function updateUI() {
    const progressBar = document.querySelector('.progress');
    const currentElement = document.querySelector('.current');
    const goalElement = document.querySelector('.goal');
    const weeklyGoalsGrid = document.querySelector('.weekly-goals-grid');

    if (progressBar && currentElement && goalElement) {
        const progressPercent = (state.dailyGoal.current / state.dailyGoal.target) * 100;
        progressBar.style.width = `${Math.min(progressPercent, 100)}%`;
        currentElement.textContent = `${state.dailyGoal.current}ml`;
        goalElement.textContent = `/ ${state.dailyGoal.target}ml`;
    }

    if (weeklyGoalsGrid) {
        weeklyGoalsGrid.innerHTML = state.weeklyGoals.map(goal => `
            <div class="goal-card">
                <div class="goal-info">
                    <div class="goal-icon">
                        <i class="fas fa-calendar-check"></i>
                    </div>
                    <div class="goal-details">
                        <h3>${goal.title}</h3>
                        <p>${goal.description}</p>
                        <div class="progress-bar">
                            <div class="progress" style="width: ${(goal.current / goal.target) * 100}%"></div>
                        </div>
                        <div class="progress-text">
                            <span>${goal.current}${goal.unit}</span>
                            <span>/ ${goal.target}${goal.unit}</span>
                        </div>
                    </div>
                </div>
            </div>
        `).join('');
    }
}

// Update achievements
function updateAchievements() {
    const achievementsGrid = document.querySelector('.achievements-grid');
    achievementsGrid.innerHTML = '';
    
    achievements.forEach(achievement => {
        const achievementCard = document.createElement('div');
        achievementCard.className = `achievement-card ${achievement.unlocked ? 'unlocked' : 'locked'}`;
        achievementCard.innerHTML = `
            <div class="achievement-icon">
                <i class="fas ${achievement.unlocked ? 'fa-trophy' : 'fa-lock'}"></i>
            </div>
            <div class="achievement-info">
                <h3>${achievement.title}</h3>
                <p>${achievement.description}</p>
                ${achievement.unlocked 
                    ? `<span class="achievement-date">Unlocked ${formatDate(achievement.date)}</span>`
                    : `<span class="achievement-progress">${achievement.progress}/${achievement.target} days</span>`
                }
            </div>
        `;
        
        achievementsGrid.appendChild(achievementCard);
    });
}

// Filter achievements
function filterAchievements(filter) {
    const filteredAchievements = achievements.filter(achievement => {
        switch (filter) {
            case 'all':
                return true;
            case 'recent':
                return achievement.unlocked && isRecent(achievement.date);
            case 'locked':
                return !achievement.unlocked;
            default:
                return true;
        }
    });
    
    const achievementsGrid = document.querySelector('.achievements-grid');
    achievementsGrid.innerHTML = '';
    
    filteredAchievements.forEach(achievement => {
        const achievementCard = document.createElement('div');
        achievementCard.className = `achievement-card ${achievement.unlocked ? 'unlocked' : 'locked'}`;
        achievementCard.innerHTML = `
            <div class="achievement-icon">
                <i class="fas ${achievement.unlocked ? 'fa-trophy' : 'fa-lock'}"></i>
            </div>
            <div class="achievement-info">
                <h3>${achievement.title}</h3>
                <p>${achievement.description}</p>
                ${achievement.unlocked 
                    ? `<span class="achievement-date">Unlocked ${formatDate(achievement.date)}</span>`
                    : `<span class="achievement-progress">${achievement.progress}/${achievement.target} days</span>`
                }
            </div>
        `;
        
        achievementsGrid.appendChild(achievementCard);
    });
}

// Utility functions
function formatDate(dateString) {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', {
        year: 'numeric',
        month: 'long',
        day: 'numeric'
    });
}

function isRecent(dateString) {
    const date = new Date(dateString);
    const now = new Date();
    const diff = now - date;
    return diff < 7 * 24 * 60 * 60 * 1000; // Within last 7 days
}

// Show success message
function showSuccess(message) {
    const toast = document.createElement('div');
    toast.className = 'toast success';
    toast.textContent = message;
    document.body.appendChild(toast);
    
    setTimeout(() => {
        toast.classList.add('show');
        setTimeout(() => {
            toast.classList.remove('show');
            setTimeout(() => toast.remove(), 300);
        }, 3000);
    }, 100);
}

// Show error message
function showError(message) {
    const toast = document.createElement('div');
    toast.className = 'toast error';
    toast.textContent = message;
    document.body.appendChild(toast);
    
    setTimeout(() => {
        toast.classList.add('show');
        setTimeout(() => {
            toast.classList.remove('show');
            setTimeout(() => toast.remove(), 300);
        }, 3000);
    }, 100);
}

// Achievement filters
achievementFilters.forEach(filter => {
    filter.addEventListener('click', () => {
        const filterType = filter.dataset.filter;
        achievementFilters.forEach(f => f.classList.remove('active'));
        filter.classList.add('active');
        filterAchievements(filterType);
    });
}); 