// DOM Elements
const dateRangeButtons = document.querySelectorAll('.date-range .btn');
const chartTypeButtons = document.querySelectorAll('.chart-controls .btn');
const intakeTrendChart = document.getElementById('intakeTrendChart');
const dailyDistributionChart = document.getElementById('dailyDistributionChart');

// Chart Instances
let trendChart;
let distributionChart;

// Sample Data (Replace with actual data from backend)
const sampleData = {
    weekly: {
        labels: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'],
        intake: [2.1, 2.3, 2.0, 2.5, 2.2, 2.4, 2.3],
        goal: 2.5
    },
    monthly: {
        labels: ['Week 1', 'Week 2', 'Week 3', 'Week 4'],
        intake: [2.2, 2.3, 2.4, 2.3],
        goal: 2.5
    },
    yearly: {
        labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
        intake: [2.1, 2.2, 2.3, 2.2, 2.4, 2.3, 2.5, 2.4, 2.3, 2.4, 2.3, 2.4],
        goal: 2.5
    },
    dailyDistribution: {
        labels: ['6AM', '9AM', '12PM', '3PM', '6PM', '9PM'],
        intake: [0.5, 0.8, 0.6, 0.4, 0.7, 0.3]
    }
};

// Initialize
document.addEventListener('DOMContentLoaded', () => {
    // Initialize GSAP animations
    initializeAnimations();
    
    // Set up event listeners
    setupEventListeners();
    
    // Initialize charts
    initializeCharts();
});

// Initialize GSAP animations
function initializeAnimations() {
    // Animate sections on load
    gsap.from('.analytics-section', {
        opacity: 0,
        y: 20,
        duration: 0.6,
        stagger: 0.2
    });
    
    // Animate stat cards
    gsap.from('.stat-card', {
        opacity: 0,
        y: 20,
        duration: 0.6,
        stagger: 0.2,
        delay: 0.4
    });
    
    // Animate insight cards
    gsap.from('.insight-card', {
        opacity: 0,
        y: 20,
        duration: 0.6,
        stagger: 0.2,
        delay: 0.6
    });
}

// Set up event listeners
function setupEventListeners() {
    // Date range buttons
    dateRangeButtons.forEach(btn => {
        btn.addEventListener('click', () => {
            dateRangeButtons.forEach(b => b.classList.remove('active'));
            btn.classList.add('active');
            updateTrendChart(btn.dataset.range);
        });
    });
    
    // Chart type buttons
    chartTypeButtons.forEach(btn => {
        btn.addEventListener('click', () => {
            chartTypeButtons.forEach(b => b.classList.remove('active'));
            btn.classList.add('active');
            updateTrendChartType(btn.dataset.chart);
        });
    });
}

// Initialize charts
function initializeCharts() {
    // Initialize trend chart
    const trendCtx = intakeTrendChart.getContext('2d');
    trendChart = new Chart(trendCtx, {
        type: 'line',
        data: {
            labels: sampleData.weekly.labels,
            datasets: [
                {
                    label: 'Water Intake (L)',
                    data: sampleData.weekly.intake,
                    borderColor: '#4CAF50',
                    backgroundColor: 'rgba(76, 175, 80, 0.1)',
                    tension: 0.4,
                    fill: true
                },
                {
                    label: 'Daily Goal',
                    data: Array(sampleData.weekly.labels.length).fill(sampleData.weekly.goal),
                    borderColor: '#FFC107',
                    borderDash: [5, 5],
                    fill: false
                }
            ]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'top',
                    labels: {
                        usePointStyle: true
                    }
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    title: {
                        display: true,
                        text: 'Liters'
                    }
                }
            }
        }
    });
    
    // Initialize distribution chart
    const distributionCtx = dailyDistributionChart.getContext('2d');
    distributionChart = new Chart(distributionCtx, {
        type: 'bar',
        data: {
            labels: sampleData.dailyDistribution.labels,
            datasets: [
                {
                    label: 'Water Intake (L)',
                    data: sampleData.dailyDistribution.intake,
                    backgroundColor: '#4CAF50',
                    borderRadius: 5
                }
            ]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    display: false
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    title: {
                        display: true,
                        text: 'Liters'
                    }
                }
            }
        }
    });
}

// Update trend chart based on date range
function updateTrendChart(range) {
    const data = sampleData[range];
    trendChart.data.labels = data.labels;
    trendChart.data.datasets[0].data = data.intake;
    trendChart.data.datasets[1].data = Array(data.labels.length).fill(data.goal);
    trendChart.update();
}

// Update trend chart type
function updateTrendChartType(type) {
    trendChart.config.type = type;
    trendChart.update();
}

// Load saved data
function loadData() {
    const savedData = localStorage.getItem('h2oTrackerAnalytics');
    if (savedData) {
        const data = JSON.parse(savedData);
        // Update charts with saved data
        updateChartsWithData(data);
    }
}

// Save data
function saveData() {
    const data = {
        weekly: sampleData.weekly,
        monthly: sampleData.monthly,
        yearly: sampleData.yearly,
        dailyDistribution: sampleData.dailyDistribution
    };
    localStorage.setItem('h2oTrackerAnalytics', JSON.stringify(data));
}

// Update charts with new data
function updateChartsWithData(data) {
    // Update trend chart
    trendChart.data.labels = data.weekly.labels;
    trendChart.data.datasets[0].data = data.weekly.intake;
    trendChart.data.datasets[1].data = Array(data.weekly.labels.length).fill(data.weekly.goal);
    trendChart.update();
    
    // Update distribution chart
    distributionChart.data.labels = data.dailyDistribution.labels;
    distributionChart.data.datasets[0].data = data.dailyDistribution.intake;
    distributionChart.update();
}

// Utility functions
function formatDate(date) {
    return new Date(date).toLocaleDateString('en-US', {
        year: 'numeric',
        month: 'long',
        day: 'numeric'
    });
}

function calculateAverage(arr) {
    return arr.reduce((a, b) => a + b, 0) / arr.length;
}

function calculatePercentage(value, total) {
    return ((value / total) * 100).toFixed(1);
} 