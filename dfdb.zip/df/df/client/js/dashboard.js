// Initialize Chart.js
const ctx = document.getElementById('waterIntakeChart').getContext('2d');
const waterIntakeChart = new Chart(ctx, {
    type: 'line',
    data: {
        labels: ['6AM', '9AM', '12PM', '3PM', '6PM', '9PM'],
        datasets: [{
            label: 'Water Intake (ml)',
            data: [250, 500, 750, 1000, 1250, 1500],
            borderColor: '#2196f3',
            backgroundColor: 'rgba(33, 150, 243, 0.1)',
            tension: 0.4,
            fill: true
        }]
    },
    options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
            legend: {
                display: false
            }
        },
        scales: {
            y: {
                beginAtZero: true,
                grid: {
                    display: true,
                    color: 'rgba(0, 0, 0, 0.05)'
                }
            },
            x: {
                grid: {
                    display: false
                }
            }
        }
    }
});

// Chart Controls
const chartControls = document.querySelectorAll('.chart-controls .btn');
chartControls.forEach(btn => {
    btn.addEventListener('click', () => {
        // Remove active class from all buttons
        chartControls.forEach(b => b.classList.remove('active'));
        // Add active class to clicked button
        btn.classList.add('active');
        
        // Update chart data based on selected time period
        const period = btn.textContent.toLowerCase();
        updateChartData(period);
    });
});

function updateChartData(period) {
    // Simulate data update with animation
    const newData = getDataForPeriod(period);
    waterIntakeChart.data.datasets[0].data = newData;
    waterIntakeChart.update('none');
}

function getDataForPeriod(period) {
    // Simulate different data for different periods
    switch(period) {
        case 'day':
            return [250, 500, 750, 1000, 1250, 1500];
        case 'week':
            return [1500, 2000, 1800, 2200, 2500, 2300];
        case 'month':
            return [2000, 2500, 2300, 2800, 3000, 2800];
        default:
            return [250, 500, 750, 1000, 1250, 1500];
    }
}

// Add Water Modal
const addWaterBtn = document.getElementById('addWaterBtn');
const addWaterModal = document.getElementById('addWaterModal');
const closeModalBtn = document.querySelector('.close-modal');
const cancelAddWaterBtn = document.getElementById('cancelAddWater');
const confirmAddWaterBtn = document.getElementById('confirmAddWater');
const amountBtns = document.querySelectorAll('.amount-btn');
const customAmountInput = document.getElementById('customAmount');
const customAmountBtn = document.querySelector('.amount-btn.custom');

// Open Modal
addWaterBtn.addEventListener('click', () => {
    addWaterModal.classList.add('active');
    document.body.style.overflow = 'hidden';
});

// Close Modal
function closeModal() {
    addWaterModal.classList.remove('active');
    document.body.style.overflow = '';
    resetModal();
}

closeModalBtn.addEventListener('click', closeModal);
cancelAddWaterBtn.addEventListener('click', closeModal);

// Close modal when clicking outside
addWaterModal.addEventListener('click', (e) => {
    if (e.target === addWaterModal) {
        closeModal();
    }
});

// Amount Selection
let selectedAmount = null;

amountBtns.forEach(btn => {
    btn.addEventListener('click', () => {
        if (btn.classList.contains('custom')) {
            // Show custom amount input
            document.querySelector('.custom-amount').style.display = 'block';
            customAmountInput.focus();
            selectedAmount = null;
        } else {
            // Select predefined amount
            document.querySelector('.custom-amount').style.display = 'none';
            amountBtns.forEach(b => b.classList.remove('active'));
            btn.classList.add('active');
            selectedAmount = parseInt(btn.dataset.amount);
        }
    });
});

// Custom Amount Input
customAmountInput.addEventListener('input', () => {
    selectedAmount = parseInt(customAmountInput.value) || null;
});

// Confirm Add Water
confirmAddWaterBtn.addEventListener('click', () => {
    if (!selectedAmount) {
        showError('Please select or enter an amount');
        return;
    }

    // Simulate API call
    confirmAddWaterBtn.classList.add('loading');
    
    setTimeout(() => {
        // Update stats and chart
        updateStats(selectedAmount);
        updateChart(selectedAmount);
        
        // Show success animation
        showSuccess();
        
        // Close modal after success
        setTimeout(closeModal, 1000);
    }, 1000);
});

function updateStats(amount) {
    // Update today's intake
    const todayIntake = document.querySelector('.stat-value');
    const currentValue = parseInt(todayIntake.textContent);
    const newValue = currentValue + (amount / 1000);
    todayIntake.textContent = `${newValue.toFixed(1)}L`;
    
    // Update progress bar
    const progressBar = document.querySelector('.stat-progress .progress-bar');
    const goal = 2.5; // 2.5L goal
    const progress = (newValue / goal) * 100;
    progressBar.style.width = `${Math.min(progress, 100)}%`;
}

function updateChart(amount) {
    const currentData = waterIntakeChart.data.datasets[0].data;
    const lastValue = currentData[currentData.length - 1];
    currentData[currentData.length - 1] = lastValue + amount;
    waterIntakeChart.update('none');
}

function showError(message) {
    const errorDiv = document.createElement('div');
    errorDiv.className = 'error-message';
    errorDiv.textContent = message;
    
    const modalBody = document.querySelector('.modal-body');
    modalBody.insertBefore(errorDiv, modalBody.firstChild);
    
    setTimeout(() => errorDiv.remove(), 3000);
}

function showSuccess() {
    const successDiv = document.createElement('div');
    successDiv.className = 'success-message';
    successDiv.innerHTML = `
        <i class="fas fa-check-circle"></i>
        <p>Successfully added ${selectedAmount}ml of water!</p>
    `;
    
    document.body.appendChild(successDiv);
    
    setTimeout(() => {
        successDiv.remove();
    }, 3000);
}

function resetModal() {
    // Reset amount selection
    amountBtns.forEach(btn => btn.classList.remove('active'));
    document.querySelector('.custom-amount').style.display = 'none';
    customAmountInput.value = '';
    selectedAmount = null;
    
    // Reset button state
    confirmAddWaterBtn.classList.remove('loading');
}

// Reminder Actions
const reminderActions = document.querySelectorAll('.reminder-action');
reminderActions.forEach(btn => {
    btn.addEventListener('click', () => {
        btn.classList.add('completed');
        setTimeout(() => {
            btn.closest('.reminder-item').remove();
        }, 500);
    });
});

// GSAP Animations
gsap.from('.stat-card', {
    duration: 0.6,
    y: 20,
    opacity: 0,
    stagger: 0.2,
    ease: 'power3.out'
});

gsap.from('.chart-section', {
    duration: 0.8,
    y: 20,
    opacity: 0,
    delay: 0.4,
    ease: 'power3.out'
});

gsap.from('.activity-item', {
    duration: 0.6,
    x: -20,
    opacity: 0,
    stagger: 0.2,
    delay: 0.6,
    ease: 'power3.out'
});

gsap.from('.reminder-item', {
    duration: 0.6,
    x: -20,
    opacity: 0,
    stagger: 0.2,
    delay: 0.8,
    ease: 'power3.out'
});

gsap.from('.tip-card', {
    duration: 0.6,
    y: 20,
    opacity: 0,
    stagger: 0.2,
    delay: 1,
    ease: 'power3.out'
});

document.addEventListener('DOMContentLoaded', () => {
    // Check if user is logged in
    const userId = localStorage.getItem('userId');
    if (!userId) {
        window.location.href = '/pages/login.html';
        return;
    }

    // Elements
    const userNameElement = document.getElementById('userName');
    const userFullNameElement = document.getElementById('userFullName');
    const userEmailElement = document.getElementById('userEmail');
    const currentDateElement = document.getElementById('currentDate');
    const caloriesBurnedElement = document.getElementById('caloriesBurned');
    const stepsCountElement = document.getElementById('stepsCount');
    const activeMinutesElement = document.getElementById('activeMinutes');
    const goalsCompletedElement = document.getElementById('goalsCompleted');
    const recentActivitiesList = document.getElementById('recentActivities');
    const goalsProgressGrid = document.getElementById('goalsProgress');
    const weeklyChart = document.getElementById('weeklyChart');
    const weekRangeElement = document.getElementById('weekRange');

    // Modals
    const addActivityModal = document.getElementById('addActivityModal');
    const addGoalModal = document.getElementById('addGoalModal');
    const activityForm = document.getElementById('activityForm');
    const goalForm = document.getElementById('goalForm');

    // Buttons
    const addActivityBtn = document.getElementById('addActivityBtn');
    const addGoalBtn = document.getElementById('addGoalBtn');
    const logoutBtn = document.getElementById('logoutBtn');
    const prevWeekBtn = document.getElementById('prevWeek');
    const nextWeekBtn = document.getElementById('nextWeek');

    // Set current date
    const today = new Date();
    currentDateElement.textContent = today.toLocaleDateString('en-US', {
        weekday: 'long',
        year: 'numeric',
        month: 'long',
        day: 'numeric'
    });

    // Fetch user data
    async function fetchUserData() {
        try {
            const response = await fetch(`/api/users/${userId}`);
            const data = await response.json();
            
            if (response.ok) {
                userNameElement.textContent = data.username.split(' ')[0];
                userFullNameElement.textContent = data.username;
                userEmailElement.textContent = data.email;
            } else {
                throw new Error(data.error);
            }
        } catch (error) {
            console.error('Error fetching user data:', error);
        }
    }

    // Fetch dashboard stats
    async function fetchDashboardStats() {
        try {
            const response = await fetch(`/api/users/${userId}/stats`);
            const data = await response.json();
            
            if (response.ok) {
                caloriesBurnedElement.textContent = data.caloriesBurned.toLocaleString();
                stepsCountElement.textContent = data.steps.toLocaleString();
                activeMinutesElement.textContent = data.activeMinutes;
                goalsCompletedElement.textContent = data.goalsCompleted;
            } else {
                throw new Error(data.error);
            }
        } catch (error) {
            console.error('Error fetching dashboard stats:', error);
        }
    }

    // Fetch recent activities
    async function fetchRecentActivities() {
        try {
            const response = await fetch(`/api/users/${userId}/activities?limit=5`);
            const data = await response.json();
            
            if (response.ok) {
                recentActivitiesList.innerHTML = data.activities.map(activity => `
                    <div class="activity-item">
                        <div class="activity-icon">
                            <i class="fas ${getActivityIcon(activity.type)}"></i>
                        </div>
                        <div class="activity-info">
                            <h4>${activity.type}</h4>
                            <p>${activity.duration} minutes • ${activity.calories} calories</p>
                            <small>${formatTimeAgo(activity.date)}</small>
                        </div>
                    </div>
                `).join('');
            } else {
                throw new Error(data.error);
            }
        } catch (error) {
            console.error('Error fetching recent activities:', error);
        }
    }

    // Fetch goals progress
    async function fetchGoalsProgress() {
        try {
            const response = await fetch(`/api/users/${userId}/goals`);
            const data = await response.json();
            
            if (response.ok) {
                goalsProgressGrid.innerHTML = data.goals.map(goal => `
                    <div class="goal-card">
                        <div class="goal-header">
                            <h3>${goal.title}</h3>
                            <p>${goal.description}</p>
                        </div>
                        <div class="goal-progress">
                            <div class="progress-bar">
                                <div class="progress" style="width: ${(goal.currentValue / goal.targetValue) * 100}%"></div>
                            </div>
                            <div class="progress-stats">
                                <span>${goal.currentValue} / ${goal.targetValue} ${goal.unit}</span>
                                <span>${Math.round((goal.currentValue / goal.targetValue) * 100)}%</span>
                            </div>
                        </div>
                    </div>
                `).join('');
            } else {
                throw new Error(data.error);
            }
        } catch (error) {
            console.error('Error fetching goals progress:', error);
        }
    }

    // Initialize weekly chart
    function initWeeklyChart() {
        const ctx = weeklyChart.getContext('2d');
        new Chart(ctx, {
            type: 'bar',
            data: {
                labels: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'],
                datasets: [{
                    label: 'Calories Burned',
                    data: [0, 0, 0, 0, 0, 0, 0],
                    backgroundColor: 'rgba(0, 13, 255, 0.2)',
                    borderColor: 'rgba(0, 13, 255, 1)',
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });
    }

    // Update weekly chart data
    async function updateWeeklyChart(startDate) {
        try {
            const response = await fetch(`/api/users/${userId}/weekly-stats?startDate=${startDate}`);
            const data = await response.json();
            
            if (response.ok) {
                weeklyChart.data.datasets[0].data = data.dailyCalories;
                weeklyChart.update();
            } else {
                throw new Error(data.error);
            }
        } catch (error) {
            console.error('Error updating weekly chart:', error);
        }
    }

    // Utility functions
    function getActivityIcon(type) {
        const icons = {
            running: 'fa-running',
            cycling: 'fa-bicycle',
            swimming: 'fa-swimmer',
            walking: 'fa-walking',
            gym: 'fa-dumbbell',
            yoga: 'fa-pray',
            other: 'fa-star'
        };
        return icons[type] || icons.other;
    }

    function formatTimeAgo(date) {
        const seconds = Math.floor((new Date() - new Date(date)) / 1000);
        
        let interval = seconds / 31536000;
        if (interval > 1) return Math.floor(interval) + ' years ago';
        
        interval = seconds / 2592000;
        if (interval > 1) return Math.floor(interval) + ' months ago';
        
        interval = seconds / 86400;
        if (interval > 1) return Math.floor(interval) + ' days ago';
        
        interval = seconds / 3600;
        if (interval > 1) return Math.floor(interval) + ' hours ago';
        
        interval = seconds / 60;
        if (interval > 1) return Math.floor(interval) + ' minutes ago';
        
        return 'just now';
    }

    // Modal handlers
    function showModal(modal) {
        modal.classList.add('active');
    }

    function hideModal(modal) {
        modal.classList.remove('active');
    }

    // Event listeners
    addActivityBtn.addEventListener('click', () => showModal(addActivityModal));
    addGoalBtn.addEventListener('click', () => showModal(addGoalModal));

    document.querySelectorAll('.close-btn').forEach(btn => {
        btn.addEventListener('click', () => {
            hideModal(addActivityModal);
            hideModal(addGoalModal);
        });
    });

    document.getElementById('cancelActivity').addEventListener('click', () => hideModal(addActivityModal));
    document.getElementById('cancelGoal').addEventListener('click', () => hideModal(addGoalModal));

    // Form submissions
    activityForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        
        const formData = {
            type: document.getElementById('activityType').value,
            duration: parseInt(document.getElementById('duration').value),
            calories: parseInt(document.getElementById('calories').value),
            notes: document.getElementById('notes').value,
            date: new Date().toISOString()
        };

        try {
            const response = await fetch('/api/tracking', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    userId,
                    ...formData
                })
            });

            if (response.ok) {
                hideModal(addActivityModal);
                activityForm.reset();
                fetchRecentActivities();
                fetchDashboardStats();
            } else {
                const data = await response.json();
                throw new Error(data.error);
            }
        } catch (error) {
            console.error('Error adding activity:', error);
            alert('Failed to add activity. Please try again.');
        }
    });

    goalForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        
        const formData = {
            type: document.getElementById('goalType').value,
            target: parseInt(document.getElementById('goalTarget').value),
            deadline: document.getElementById('goalDeadline').value,
            notes: document.getElementById('goalNotes').value
        };

        try {
            const response = await fetch('/api/goals', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    userId,
                    ...formData
                })
            });

            if (response.ok) {
                hideModal(addGoalModal);
                goalForm.reset();
                fetchGoalsProgress();
            } else {
                const data = await response.json();
                throw new Error(data.error);
            }
        } catch (error) {
            console.error('Error adding goal:', error);
            alert('Failed to add goal. Please try again.');
        }
    });

    // Logout handler
    logoutBtn.addEventListener('click', () => {
        localStorage.removeItem('userId');
        window.location.href = '/pages/login.html';
    });

    // Initialize dashboard
    fetchUserData();
    fetchDashboardStats();
    fetchRecentActivities();
    fetchGoalsProgress();
    initWeeklyChart();
    updateWeeklyChart(new Date().toISOString());
}); 