// Form Elements
const forgotPasswordForm = document.getElementById('forgotPasswordForm');
const emailInput = document.getElementById('email');
const submitBtn = document.querySelector('.btn-block');
const successMessage = document.querySelector('.success-message');

// Form Validation
function validateEmail(email) {
    const re = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    return re.test(String(email).toLowerCase());
}

function showError(input, message) {
    const formGroup = input.parentElement.parentElement;
    const errorDiv = formGroup.querySelector('.error-message');
    errorDiv.textContent = message;
    formGroup.classList.add('error-shake');
    setTimeout(() => formGroup.classList.remove('error-shake'), 500);
}

function clearError(input) {
    const formGroup = input.parentElement.parentElement;
    const errorDiv = formGroup.querySelector('.error-message');
    errorDiv.textContent = '';
}

// Input Validation
emailInput.addEventListener('input', () => {
    if (!validateEmail(emailInput.value)) {
        showError(emailInput, 'Please enter a valid email address');
    } else {
        clearError(emailInput);
    }
});

// Form Submission
forgotPasswordForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    
    // Validate email
    if (!validateEmail(emailInput.value)) {
        showError(emailInput, 'Please enter a valid email address');
        return;
    }
    
    // Show loading state
    submitBtn.classList.add('loading');
    
    try {
        // Simulate API call
        await new Promise(resolve => setTimeout(resolve, 1500));
        
        // Hide form and show success message
        forgotPasswordForm.style.display = 'none';
        successMessage.style.display = 'block';
        
        // Animate success message
        gsap.from(successMessage, {
            duration: 0.6,
            y: 20,
            opacity: 0,
            ease: 'power3.out'
        });
        
        // Redirect after success
        setTimeout(() => {
            window.location.href = 'login.html';
        }, 3000);
        
    } catch (error) {
        // Show error state
        submitBtn.classList.remove('loading');
        submitBtn.innerHTML = '<span>Error occurred. Please try again.</span>';
        
        // Reset button after error
        setTimeout(() => {
            submitBtn.innerHTML = '<span>Send Reset Link</span><div class="spinner"></div>';
        }, 2000);
    }
});

// GSAP Animations
gsap.from('.auth-header', {
    duration: 0.8,
    y: -20,
    opacity: 0,
    ease: 'power3.out'
});

gsap.from('.form-group', {
    duration: 0.6,
    y: 20,
    opacity: 0,
    ease: 'power3.out',
    delay: 0.3
});

gsap.from('.btn-block', {
    duration: 0.6,
    y: 20,
    opacity: 0,
    ease: 'power3.out',
    delay: 0.6
});

gsap.from('.auth-footer', {
    duration: 0.6,
    y: 20,
    opacity: 0,
    ease: 'power3.out',
    delay: 0.8
}); 