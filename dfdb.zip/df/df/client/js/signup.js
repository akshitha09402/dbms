// Form Elements
const signupForm = document.getElementById('signupForm');
const nameInput = document.getElementById('name');
const emailInput = document.getElementById('email');
const passwordInput = document.getElementById('password');
const confirmPasswordInput = document.getElementById('confirmPassword');
const togglePasswordBtns = document.querySelectorAll('.toggle-password');
const submitBtn = document.querySelector('.btn-block');
const termsCheckbox = document.getElementById('terms');

// Toggle Password Visibility
togglePasswordBtns.forEach(btn => {
    btn.addEventListener('click', () => {
        const input = btn.parentElement.querySelector('input');
        const type = input.getAttribute('type') === 'password' ? 'text' : 'password';
        input.setAttribute('type', type);
        btn.querySelector('i').classList.toggle('fa-eye');
        btn.querySelector('i').classList.toggle('fa-eye-slash');
    });
});

// Error Elements
const nameError = document.getElementById('nameError');
const emailError = document.getElementById('emailError');
const passwordError = document.getElementById('passwordError');
const confirmPasswordError = document.getElementById('confirmPasswordError');
const termsError = document.getElementById('termsError');

// Form Validation
function validateEmail(email) {
    const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return re.test(String(email).toLowerCase());
}

function validateName(name) {
    return name.length >= 2 && /^[a-zA-Z\s]*$/.test(name);
}

function validatePassword(password) {
    return password.length >= 8;
}

function showError(element, message) {
    if (element) {
        element.textContent = message;
        element.style.display = 'block';
        const input = element.parentElement.querySelector('input');
        if (input) {
            input.classList.add('error');
        }
    }
}

function clearError(element) {
    if (element) {
        element.textContent = '';
        element.style.display = 'none';
        const input = element.parentElement.querySelector('input');
        if (input) {
            input.classList.remove('error');
        }
    }
}

function clearAllErrors() {
    clearError(nameError);
    clearError(emailError);
    clearError(passwordError);
    clearError(confirmPasswordError);
    clearError(termsError);
}

function setButtonState(state, message = '') {
    switch (state) {
        case 'loading':
            submitBtn.classList.add('loading');
            submitBtn.disabled = true;
            break;
        case 'error':
            submitBtn.classList.remove('loading');
            submitBtn.innerHTML = `<span>${message || 'Error occurred. Please try again.'}</span>`;
            submitBtn.disabled = false;
            // Reset button after error
            setTimeout(() => {
                submitBtn.innerHTML = '<span>Create Account</span><div class="spinner"></div>';
            }, 3000);
            break;
        case 'success':
            submitBtn.classList.remove('loading');
            submitBtn.innerHTML = '<span>Success! Redirecting...</span>';
            submitBtn.disabled = true;
            break;
        default:
            submitBtn.classList.remove('loading');
            submitBtn.innerHTML = '<span>Create Account</span><div class="spinner"></div>';
            submitBtn.disabled = false;
    }
}

// Input Validation
nameInput.addEventListener('input', () => {
    if (!validateName(nameInput.value)) {
        showError(nameError, 'Please enter a valid name (letters and spaces only)');
    } else {
        clearError(nameError);
    }
});

emailInput.addEventListener('input', () => {
    if (!validateEmail(emailInput.value)) {
        showError(emailError, 'Please enter a valid email address');
    } else {
        clearError(emailError);
    }
});

passwordInput.addEventListener('input', () => {
    if (!validatePassword(passwordInput.value)) {
        showError(passwordError, 'Password must be at least 8 characters long');
    } else {
        clearError(passwordError);
        if (confirmPasswordInput.value) {
            if (confirmPasswordInput.value !== passwordInput.value) {
                showError(confirmPasswordError, 'Passwords do not match');
            } else {
                clearError(confirmPasswordError);
            }
        }
    }
});

confirmPasswordInput.addEventListener('input', () => {
    if (confirmPasswordInput.value !== passwordInput.value) {
        showError(confirmPasswordError, 'Passwords do not match');
    } else {
        clearError(confirmPasswordError);
    }
});

// Form Submission
signupForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    clearAllErrors();
    
    // Validate all fields
    let isValid = true;
    
    if (!validateName(nameInput.value)) {
        showError(nameError, 'Please enter a valid name (letters and spaces only)');
        isValid = false;
    }
    
    if (!validateEmail(emailInput.value)) {
        showError(emailError, 'Please enter a valid email address');
        isValid = false;
    }
    
    if (!validatePassword(passwordInput.value)) {
        showError(passwordError, 'Password must be at least 8 characters long');
        isValid = false;
    }
    
    if (confirmPasswordInput.value !== passwordInput.value) {
        showError(confirmPasswordError, 'Passwords do not match');
        isValid = false;
    }
    
    if (!termsCheckbox.checked) {
        showError(termsError, 'You must agree to the Terms of Service and Privacy Policy');
        isValid = false;
    }
    
    if (!isValid) return;
    
    setButtonState('loading');
    
    try {
        console.log('Submitting form data...');
        const formData = {
            fullName: nameInput.value.trim(),
            email: emailInput.value.trim(),
            password: passwordInput.value,
            confirmPassword: confirmPasswordInput.value
        };
        console.log('Form data:', { ...formData, password: '***' });

        const response = await fetch('/api/auth/register', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(formData)
        });

        console.log('Response status:', response.status);
        const data = await response.json();
        console.log('Response data:', data);

        if (response.ok) {
            setButtonState('success');
            localStorage.setItem('userId', data.userId);
            
            // Show success message
            const successMessage = document.createElement('div');
            successMessage.className = 'success-message';
            successMessage.textContent = 'Account created successfully!';
            submitBtn.parentNode.insertBefore(successMessage, submitBtn.nextSibling);
            
            // Redirect to dashboard after a brief delay
            setTimeout(() => {
                window.location.href = '/dashboard';
            }, 1500);
        } else {
            throw new Error(data.error || 'Failed to create account');
        }
    } catch (error) {
        console.error('Signup error:', error);
        
        // Show specific error message to the user
        if (error.message.includes('email')) {
            showError(emailError, error.message);
        } else if (error.message.includes('username')) {
            showError(nameError, error.message);
        } else if (error.message.includes('password')) {
            showError(passwordError, error.message);
        } else {
            // Show general error
            setButtonState('error', error.message);
        }
    }
});

// GSAP Animations
gsap.from('.auth-header', {
    duration: 0.8,
    y: -20,
    opacity: 0,
    ease: 'power3.out'
});

gsap.from('.form-group', {
    duration: 0.6,
    y: 20,
    opacity: 0,
    stagger: 0.1,
    ease: 'power3.out',
    delay: 0.3
});

gsap.from('.btn-block', {
    duration: 0.6,
    y: 20,
    opacity: 0,
    ease: 'power3.out',
    delay: 0.8
});

gsap.from('.auth-footer', {
    duration: 0.6,
    y: 20,
    opacity: 0,
    ease: 'power3.out',
    delay: 1
}); 