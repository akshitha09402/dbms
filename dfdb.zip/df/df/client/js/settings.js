// DOM Elements
const saveAccountBtn = document.getElementById('saveAccountBtn');
const savePreferencesBtn = document.getElementById('savePreferencesBtn');
const saveNotificationsBtn = document.getElementById('saveNotificationsBtn');
const deleteAccountBtn = document.getElementById('deleteAccountBtn');
const deleteAccountModal = document.getElementById('deleteAccountModal');
const closeModalBtn = document.querySelector('.close-modal');
const cancelDeleteBtn = document.getElementById('cancelDeleteBtn');
const confirmDeleteBtn = document.getElementById('confirmDeleteBtn');
const uploadImageBtn = document.getElementById('uploadImageBtn');
const profilePreview = document.getElementById('profilePreview');
const togglePasswordBtns = document.querySelectorAll('.toggle-password');

// State
let settings = {
    account: {
        fullName: '',
        email: '',
        profileImage: ''
    },
    preferences: {
        measurementUnit: 'ml',
        theme: 'light',
        language: 'en',
        timezone: 'UTC'
    },
    notifications: {
        hydrationReminders: true,
        goalAchievement: true,
        weeklyReports: true,
        streakAlerts: true,
        reminderFrequency: '60',
        quietHoursStart: '22:00',
        quietHoursEnd: '07:00'
    }
};

// Initialize
document.addEventListener('DOMContentLoaded', () => {
    // Initialize GSAP animations
    initializeAnimations();
    
    // Load saved settings
    loadSettings();
    
    // Set up event listeners
    setupEventListeners();
});

// Initialize GSAP animations
function initializeAnimations() {
    // Animate sections on load
    gsap.from('.settings-section', {
        opacity: 0,
        y: 20,
        duration: 0.6,
        stagger: 0.2
    });
}

// Load saved settings
function loadSettings() {
    const savedSettings = localStorage.getItem('h2oTrackerSettings');
    if (savedSettings) {
        settings = JSON.parse(savedSettings);
        updateFormValues();
    }
}

// Save settings
function saveSettings() {
    localStorage.setItem('h2oTrackerSettings', JSON.stringify(settings));
}

// Update form values with current settings
function updateFormValues() {
    // Account settings
    document.getElementById('fullName').value = settings.account.fullName;
    document.getElementById('email').value = settings.account.email;
    if (settings.account.profileImage) {
        profilePreview.src = settings.account.profileImage;
    }
    
    // Preferences
    document.getElementById('measurementUnit').value = settings.preferences.measurementUnit;
    document.getElementById('theme').value = settings.preferences.theme;
    document.getElementById('language').value = settings.preferences.language;
    document.getElementById('timezone').value = settings.preferences.timezone;
    
    // Notifications
    document.getElementById('hydrationReminders').checked = settings.notifications.hydrationReminders;
    document.getElementById('goalAchievement').checked = settings.notifications.goalAchievement;
    document.getElementById('weeklyReports').checked = settings.notifications.weeklyReports;
    document.getElementById('streakAlerts').checked = settings.notifications.streakAlerts;
    document.getElementById('reminderFrequency').value = settings.notifications.reminderFrequency;
    document.getElementById('quietHoursStart').value = settings.notifications.quietHoursStart;
    document.getElementById('quietHoursEnd').value = settings.notifications.quietHoursEnd;
}

// Set up event listeners
function setupEventListeners() {
    // Account settings
    saveAccountBtn.addEventListener('click', saveAccountSettings);
    uploadImageBtn.addEventListener('click', handleImageUpload);
    
    // Preferences
    savePreferencesBtn.addEventListener('click', savePreferences);
    
    // Notifications
    saveNotificationsBtn.addEventListener('click', saveNotificationSettings);
    
    // Delete account
    deleteAccountBtn.addEventListener('click', () => openModal(deleteAccountModal));
    closeModalBtn.addEventListener('click', () => closeModal(deleteAccountModal));
    cancelDeleteBtn.addEventListener('click', () => closeModal(deleteAccountModal));
    confirmDeleteBtn.addEventListener('click', handleAccountDeletion);
    
    // Password visibility toggle
    togglePasswordBtns.forEach(btn => {
        btn.addEventListener('click', () => {
            const input = btn.previousElementSibling;
            const type = input.type === 'password' ? 'text' : 'password';
            input.type = type;
            btn.querySelector('i').className = type === 'password' ? 'fas fa-eye' : 'fas fa-eye-slash';
        });
    });
}

// Handle account settings save
function saveAccountSettings() {
    const fullName = document.getElementById('fullName').value.trim();
    const email = document.getElementById('email').value.trim();
    const currentPassword = document.getElementById('currentPassword').value;
    const newPassword = document.getElementById('newPassword').value;
    const confirmPassword = document.getElementById('confirmPassword').value;
    
    // Validate inputs
    if (!fullName || !email) {
        showError('Please fill in all required fields');
        return;
    }
    
    if (!validateEmail(email)) {
        showError('Please enter a valid email address');
        return;
    }
    
    if (newPassword) {
        if (newPassword !== confirmPassword) {
            showError('New passwords do not match');
            return;
        }
        
        if (!currentPassword) {
            showError('Please enter your current password');
            return;
        }
    }
    
    // Update settings
    settings.account.fullName = fullName;
    settings.account.email = email;
    
    // Save settings
    saveSettings();
    
    // Show success message
    showSuccess('Account settings updated successfully');
    
    // Clear password fields
    document.getElementById('currentPassword').value = '';
    document.getElementById('newPassword').value = '';
    document.getElementById('confirmPassword').value = '';
}

// Handle preferences save
function savePreferences() {
    settings.preferences.measurementUnit = document.getElementById('measurementUnit').value;
    settings.preferences.theme = document.getElementById('theme').value;
    settings.preferences.language = document.getElementById('language').value;
    settings.preferences.timezone = document.getElementById('timezone').value;
    
    saveSettings();
    showSuccess('Preferences updated successfully');
    
    // Apply theme
    applyTheme(settings.preferences.theme);
}

// Handle notification settings save
function saveNotificationSettings() {
    settings.notifications.hydrationReminders = document.getElementById('hydrationReminders').checked;
    settings.notifications.goalAchievement = document.getElementById('goalAchievement').checked;
    settings.notifications.weeklyReports = document.getElementById('weeklyReports').checked;
    settings.notifications.streakAlerts = document.getElementById('streakAlerts').checked;
    settings.notifications.reminderFrequency = document.getElementById('reminderFrequency').value;
    settings.notifications.quietHoursStart = document.getElementById('quietHoursStart').value;
    settings.notifications.quietHoursEnd = document.getElementById('quietHoursEnd').value;
    
    saveSettings();
    showSuccess('Notification settings updated successfully');
}

// Handle profile image upload
function handleImageUpload() {
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = 'image/*';
    
    input.addEventListener('change', (e) => {
        const file = e.target.files[0];
        if (file) {
            const reader = new FileReader();
            reader.onload = (e) => {
                profilePreview.src = e.target.result;
                settings.account.profileImage = e.target.result;
                saveSettings();
                showSuccess('Profile image updated successfully');
            };
            reader.readAsDataURL(file);
        }
    });
    
    input.click();
}

// Handle account deletion
function handleAccountDeletion() {
    const password = document.getElementById('deleteConfirmPassword').value;
    
    if (!password) {
        showError('Please enter your password to confirm deletion');
        return;
    }
    
    // Here you would typically make an API call to delete the account
    // For now, we'll just clear local storage and redirect
    localStorage.clear();
    window.location.href = 'login.html';
}

// Modal functions
function openModal(modal) {
    modal.classList.add('active');
    document.body.style.overflow = 'hidden';
}

function closeModal(modal) {
    modal.classList.remove('active');
    document.body.style.overflow = '';
    document.getElementById('deleteConfirmPassword').value = '';
}

// Theme application
function applyTheme(theme) {
    document.body.className = `dashboard-page ${theme}-theme`;
}

// Utility functions
function validateEmail(email) {
    const re = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    return re.test(String(email).toLowerCase());
}

function showSuccess(message) {
    const toast = document.createElement('div');
    toast.className = 'toast success';
    toast.textContent = message;
    
    document.body.appendChild(toast);
    
    gsap.fromTo(toast,
        { opacity: 0, y: 20 },
        { opacity: 1, y: 0, duration: 0.3 }
    );
    
    setTimeout(() => {
        gsap.to(toast, {
            opacity: 0,
            y: 20,
            duration: 0.3,
            onComplete: () => toast.remove()
        });
    }, 3000);
}

function showError(message) {
    const toast = document.createElement('div');
    toast.className = 'toast error';
    toast.textContent = message;
    
    document.body.appendChild(toast);
    
    gsap.fromTo(toast,
        { opacity: 0, y: 20 },
        { opacity: 1, y: 0, duration: 0.3 }
    );
    
    setTimeout(() => {
        gsap.to(toast, {
            opacity: 0,
            y: 20,
            duration: 0.3,
            onComplete: () => toast.remove()
        });
    }, 3000);
} 