document.addEventListener('DOMContentLoaded', () => {
    const loginForm = document.getElementById('loginForm');
    const emailInput = document.getElementById('email');
    const passwordInput = document.getElementById('password');
    const emailError = document.getElementById('emailError');
    const passwordError = document.getElementById('passwordError');

    function showError(element, message) {
        element.textContent = message;
        element.style.display = 'block';
    }

    function clearError(element) {
        element.textContent = '';
        element.style.display = 'none';
    }

    function validateEmail(email) {
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return emailRegex.test(email);
    }

    emailInput.addEventListener('input', () => {
        if (!validateEmail(emailInput.value)) {
            showError(emailError, 'Please enter a valid email address');
        } else {
            clearError(emailError);
        }
    });

    passwordInput.addEventListener('input', () => {
        if (passwordInput.value.length < 6) {
            showError(passwordError, 'Password must be at least 6 characters long');
        } else {
            clearError(passwordError);
        }
    });

    loginForm.addEventListener('submit', async (e) => {
        e.preventDefault();

        // Clear any existing errors
        clearError(emailError);
        clearError(passwordError);

        // Validate inputs
        let hasError = false;

        if (!validateEmail(emailInput.value)) {
            showError(emailError, 'Please enter a valid email address');
            hasError = true;
        }

        if (passwordInput.value.length < 6) {
            showError(passwordError, 'Password must be at least 6 characters long');
            hasError = true;
        }

        if (hasError) {
            return;
        }

        // Show loading state
        const submitButton = loginForm.querySelector('button[type="submit"]');
        submitButton.classList.add('loading');

        try {
            const response = await fetch('/api/auth/login', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    email: emailInput.value,
                    password: passwordInput.value,
                    remember: document.getElementById('remember').checked
                }),
            });

            const data = await response.json();

            if (response.ok) {
                // Store user data
                localStorage.setItem('userId', data.userId);
                localStorage.setItem('username', data.username);
                localStorage.setItem('userEmail', data.email);
                
                // Store email for remember me functionality
                if (document.getElementById('remember').checked) {
                    localStorage.setItem('rememberedEmail', emailInput.value);
                } else {
                    localStorage.removeItem('rememberedEmail');
                }
                
                // Redirect to dashboard
                window.location.href = 'dashboard.html';
            } else {
                // Show error message
                showError(emailError, data.error || 'Invalid email or password');
                submitButton.classList.remove('loading');
            }
        } catch (error) {
            showError(emailError, 'An error occurred. Please try again later.');
            console.error('Login error:', error);
            submitButton.classList.remove('loading');
        }
    });

    // Check for remembered email
    const rememberedEmail = localStorage.getItem('rememberedEmail');
    if (rememberedEmail) {
        emailInput.value = rememberedEmail;
        document.getElementById('remember').checked = true;
    }
}); 