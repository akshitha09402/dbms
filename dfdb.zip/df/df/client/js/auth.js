// Form Elements
const loginForm = document.getElementById('loginForm');
const emailInput = document.getElementById('email');
const passwordInput = document.getElementById('password');
const togglePasswordBtn = document.querySelector('.toggle-password');
const submitBtn = document.querySelector('.btn-block');

// Toggle Password Visibility
togglePasswordBtn.addEventListener('click', () => {
    const type = passwordInput.getAttribute('type') === 'password' ? 'text' : 'password';
    passwordInput.setAttribute('type', type);
    togglePasswordBtn.querySelector('i').classList.toggle('fa-eye');
    togglePasswordBtn.querySelector('i').classList.toggle('fa-eye-slash');
});

// Form Validation
function validateEmail(email) {
    const re = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    return re.test(String(email).toLowerCase());
}

function showError(input, message) {
    const formGroup = input.parentElement.parentElement;
    const errorDiv = formGroup.querySelector('.error-message');
    errorDiv.textContent = message;
    formGroup.classList.add('error-shake');
    setTimeout(() => formGroup.classList.remove('error-shake'), 500);
}

function clearError(input) {
    const formGroup = input.parentElement.parentElement;
    const errorDiv = formGroup.querySelector('.error-message');
    errorDiv.textContent = '';
}

// Input Validation
emailInput.addEventListener('input', () => {
    if (!validateEmail(emailInput.value)) {
        showError(emailInput, 'Please enter a valid email address');
    } else {
        clearError(emailInput);
    }
});

passwordInput.addEventListener('input', () => {
    if (passwordInput.value.length < 6) {
        showError(passwordInput, 'Password must be at least 6 characters long');
    } else {
        clearError(passwordInput);
    }
});

// Form Submission
loginForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    
    // Validate all fields
    let isValid = true;
    
    if (!validateEmail(emailInput.value)) {
        showError(emailInput, 'Please enter a valid email address');
        isValid = false;
    }
    
    if (passwordInput.value.length < 6) {
        showError(passwordInput, 'Password must be at least 6 characters long');
        isValid = false;
    }
    
    if (!isValid) return;
    
    // Show loading state
    submitBtn.classList.add('loading');
    
    try {
        // Simulate API call
        await new Promise(resolve => setTimeout(resolve, 1500));
        
        // Show success animation
        const successCheckmark = document.createElement('div');
        successCheckmark.className = 'success-checkmark';
        successCheckmark.innerHTML = '<i class="fas fa-check"></i>';
        
        submitBtn.innerHTML = '';
        submitBtn.appendChild(successCheckmark);
        
        // Redirect after success
        setTimeout(() => {
            window.location.href = 'dashboard.html';
        }, 1000);
        
    } catch (error) {
        // Show error state
        submitBtn.classList.remove('loading');
        submitBtn.innerHTML = '<span>Error occurred. Please try again.</span>';
        
        // Reset button after error
        setTimeout(() => {
            submitBtn.innerHTML = '<span>Sign In</span><div class="spinner"></div>';
        }, 2000);
    }
});

// Remember Me Functionality
const rememberMe = document.querySelector('input[name="remember"]');
const savedEmail = localStorage.getItem('rememberedEmail');

if (savedEmail) {
    emailInput.value = savedEmail;
    rememberMe.checked = true;
}

rememberMe.addEventListener('change', () => {
    if (rememberMe.checked) {
        localStorage.setItem('rememberedEmail', emailInput.value);
    } else {
        localStorage.removeItem('rememberedEmail');
    }
});

// GSAP Animations
gsap.from('.auth-header', {
    duration: 0.8,
    y: -20,
    opacity: 0,
    ease: 'power3.out'
});

gsap.from('.form-group', {
    duration: 0.6,
    y: 20,
    opacity: 0,
    stagger: 0.1,
    ease: 'power3.out',
    delay: 0.3
});

gsap.from('.form-options', {
    duration: 0.6,
    y: 20,
    opacity: 0,
    ease: 'power3.out',
    delay: 0.6
});

gsap.from('.btn-block', {
    duration: 0.6,
    y: 20,
    opacity: 0,
    ease: 'power3.out',
    delay: 0.8
});

gsap.from('.auth-footer', {
    duration: 0.6,
    y: 20,
    opacity: 0,
    ease: 'power3.out',
    delay: 1
}); 